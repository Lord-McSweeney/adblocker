var injectScript = document.createElement('script');
injectScript.src = chrome.runtime.getURL('inject.js');
injectScript.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(injectScript);

var imaStubScript = document.createElement('script');
imaStubScript.src = chrome.runtime.getURL('fake-imasdk.js');
imaStubScript.onload = function() {
    this.remove();
};
(document.head || document.documentElement).appendChild(imaStubScript);
