(function() {
    var debug = {
        enabled: false, // basic profiler for slow sites and debugger if elements are removed
        currentstring: "",
        starttime: 0,
        debugTime: function(string) {
            if (this.enabled) {
                if (this.currentstring) {
                    console.log(this.currentstring, Date.now() - this.starttime);
                }
                this.currentstring = string;
                this.starttime = Date.now();
            }
        }
    }
    
    var logger = {
        logcount: 0,
        maxlogmessages: 50,
        log: function() {
            this.logcount ++;
            if (this.logcount > (this.maxlogmessages + 1) && !debug.enabled) {
                return;
            }
            if (this.logcount === (this.maxlogmessages + 1) && !debug.enabled) {
                console.log("Logcount exceeded " + this.maxlogmessages + ", shutting up...");
                return;
            }
            console.log(...Array.from(arguments));
        }
    }
    
    var removeclasses = ["js-sidebar-zone", "js-zone-container", "adsbygoogle", "adtester-container-100", "adtester-container", "ad-container", "zmgad-right-rail", "zmgad-full-width", "top-ads-container", "aff-unit__wrapper", "v_300_large", "v_970_billboard", "v_728_leaderboard", "topbannerAd", "ad", "ad-stickyhero--standard", "sidebar-ads-holder-top", "content-ads-holder", "dfp-leaderboard-container", "ad-unit", "adunit", ["space.com", "bordeaux-generated-spacer"], ["space.com", "bordeaux-filled-slot"], "trc_spotlight_widget", ["vice.com", "docked-slot-renderer", true], ["vice.com", "sticky-wrapper", true], ["vice.com", "bx-slab", true], ["vice.com", "adph"], "ADSlot", ["autooverload.com", "stickyfooter"], "udm-ad", ["archaeology.org", "top_black"], ["oceandraw.com", "bottom-of-post"], /*depends on if you want to see reddit promoted links -->*/ ["reddit.com", "promotedlink"], ["xeiaso.net", "adaptive"], "c-adSkyBox", "c-adSkyBox_expanded", "c-adDisplay_container", "c-adDisplay_container_incontent-ad-plus-billboard-bottom", ["isoriver.com", "isori-before-content"], "fbs-ad--top-wrapper", "fbs-ad--topx-wrapper", "pure-u-custom-ad-rectangle", "ads-column", "ads-left", "ads-right", "pure-u-custom-ad-skyscraper", "ad-placement", "afs_ads", ["ieee.org", "top-leader-container"], "sidebar_ad_container", "rbl-ad", ["ieee.org", "rblad-ieee_in_content"], "trc_rbox_container", "taboola", ["bloomberg.com", "leaderboard-container"], ["ieee.org", "rblad-ieee_infinite_leaderboard"], "ad-incontent-all-top", "ad-slot", "js-immediate-ad", "js-scads-inline-content", "mntl-flexible-ad", "mntl-gpt-adunit", "m-ad", "m-ad__dynamic_ad_unit", "m-ad__medium_rectangle_short", "dfp_ad-wrapper--is-filled", "dfp_ad--held-area", "dfp_ad--rendered", "dfp_ad--is-filled", ".dfp_ad--held-area", "dfp_ad--full-width", "dfp_ad--outbrain", "outbrain-wrapper", "slot-box-marker-ad", "sticky_ad", "ad-label", "multiple-ads-container", "ad2", "ob-smartfeed-wrapper", "taboola-mid-article-thumbnails12", "quads-ad-label", ["loansocieties.com", "sde-sidebar"], ["loansocieties.com", "quads-location"], "bottom_sticky_ad", "outbrain-container", "adtitle", "advertisement", "adtop", "ad-wrapper", "TopBanner-container", "ad--text-alignment", "ad--sticky", "ad--front", "top-ad-container", "ad-mpu-plus-top-right-rail", "ad-group", "ob-widget", "OUTBRAIN", "display-ad-container", "diy-adhesion-container", "ad-widget-wrapper", "anchored-ad-widget", "primary-ad-wrapper", "adWrapper", "adContainer", "l-ad", "subnav-ad-layout", "sticky-footer-ad", "widget-ads-ads-lightbox2", "bordeaux-generated-container", "ad-slot-rail", "ad-slot-header", "shemedia-ad-wrapper", "ad-container-div", "pmc-atlasmg-ad-type-frame2", ["forbes.com", "view-offer"], ["forbes.com", "tp-modal"], "proper-ad-unit", ["apnews.com", "Leaderboard"], "persistent-ad", "apnews_article_rectangle_1_1", "ntv-feed", "ntv-feed-video", "ntvClickOut", "native-ad-item", ["news.yahoo.com", "caas-iframe-wrapper"], "vendor-unit", "ad_wrapper", "ad_notice", ["arstechnica.com", "xrail"], "adsbyvli", "vm-adunit-outer", "dom_annotate_ad_image_ad", ["convertingcolors.com", "_bsa_flexbar"], "bb-ad", "newsletter_signup", "pushcrew-chrome-style-notification", "slate-ad", "ad--tabletPortraitOnly", "ad--inArticleBanner", "top-ad", "c-ad", "revcontent-wrap", "ad-called", "ad-loaded", "ad-loaded--standard", "ad-loaded-dom", "ad-panel", "amzn-safe-frame-container", "themonic-ad1", "themonic-ad2", "themonic-ad3", "themonic-ad4", "themonic-ad5", "themonic-ad6", "apnews_article_midarticle_1", "apnews_article_midarticle_2", "apnews_article_midarticle_3", "apnews_article_midarticle_4", "apnews_article_midarticle_5", "apnews_article_midarticle_6", ["washingtonpost.com", "adslot-c", true], "checkout-paywall-overlay", "ad--desktop", ["npr.org", "backstage-sponsor-language"], "container--ads", "container--ads-leaderboard-atf", ["!mail.google.com", "ads"], "container--section-page-ads", ["sciencenews.org", "modal-subscribe"], "dianomi_context", "ad_container", "top_ad_wrapper", "list-item-yield-ad", "breaker-ad", ["goodhousekeeping.com", "journey-container-wrapper"], "gpt-leaderboard-ad", "BoxRail-ad", "adun", "tp-modal", "tp-backdrop", "tp-container-inner", "adUnit", /*depends on if you want to see quora promoted ads -->*/ "spacing_log_question_page_ad", "dfp-ad", "dfp-interstitial", ["mercurynews.com", "ntv-box"], "taboola-skip-wrapper", "puff-ad", "mol-ads-label-container", "mol-ads-label", "adHolder", "noAdLabel", "mol-ads-skin-label-container", ["dailymail.co.uk", "mpu_puff_wrapper"], "o-ad-container", "m-block-ad", "tms-ad", ["hurriyet.com.tr", "adv"], ["hurriyet.com.tr", "adv-desktop"], ["hurriyet.com.tr", "tb-adv"], ["hurriyet.com.tr", "sticky-wrapper"], ["sparknotes.com", "sn-promo-modal"], ["sparknotes.com", "partner__pw__header"], "ads-search-sidebar", "ad-rectangle", "advertorials__container", "google-dfp-ad-wrapper", "server-forum-after-comment-ad", "adthrive-ad", "adwrap", "adwrap-unviewed", "top-banner-ad-container", "footer-ad-labeling", "primis-ad-wrap", "adv-card", "Ad-isFixed", "Ad-adhesive", "Ad-adhesive--bottom", "Ad-adhesive-body", "Ad", "advert--banner", "advert-label--sidebar", "js-advert", "adslot", ["venturebeat.com", "tude-cw-wrap"], "trc_popover", "trc_bottom", ["latimes.com", "met-sub-link"], ["telegraph.co.uk", "martech-footer-overlay"], ["cpomagazine.com", "block-da-header_top"], "adtitle", "ad-banner", "adsense-ad", "interstitial", "survey-modal", "mv-ad-box", "carbonads-widget", "tadm_ad_unit", "empire-unit-prefill-container", ["news.yahoo.com", "viewer-sda-container"], "ad-risingstar-container", "big-button-ads", ["ipalibrary.me", "swal2-container"], ["seriesperu.com", "-blackout"], "mwtad-sidebar-ad-1", "mwtad-sidebar-ad-2", "navbar-ad-container", "leaderboard-banner", "ad-inline", "ad-disclaimer", "intra-article-module intra-article-ad-half", "zergnet-widget", "google-ad-placeholder", "above-header-ad", "admz", "widget_pmc-ads-widget", "mwtad-sidebar", ["nationalgeographic.com", "EmailStickyFooter__Modal"], "InsertedAd", ["nationalgeographic.com", "PaywallModal"], "block-adstop-homepage-728x90", "block-adstop-otherpage-728x90", "AdzerkBanner", "AdzerkSideBanner", "vestpocket", "cpoma-widget", ["cpomagazine.com", "zeen-da-wrap"], "dotcom-ad", "adslot--mpu", "amp-adv-wrapper", "i-amphtml-sticky-ad-layout", "ad-middle", "sidebar-ad-block", "square-ad-top", "square-ad-bottom", "adbox", ["speedrun.com", "engage-unit-container", true], ["*", "grid__module-sizer_name_taboola", false, 1], ["www.svgviewer.dev", "banner-container"], "js_rev-content-placeholder", ["moneysave.info", "adblock_title", false, 5], ["*", "-modal -the-modal active", false, 1, function() {
        if (document.body && document.body.classList) {
            document.body.classList.remove("-blur");
        }
        var elems = document.getElementsByClassName("-blackout active")[0];
        if (elems instanceof HTMLElement) {
            elems.remove();
        }
        if (document.body.style.cssText.includes("cursor: default;")) {
            document.body.style.cssText = document.body.style.cssText.replaceAll("cursor: default;", "");
        }
        document.oncontextmenu = null;
        document.body.oncontextmenu = null;
        document.body.onselectstart = null;
        document.ondragstart = null;
        document.onkeydown = null;
    }], ["washingtonpost.com", "overflow-hidden flex justify-center hide-for-print", false, 0, function() {
        if (document.body && document.body.style) {
            document.body.style.cssText = document.body.style.cssText.replaceAll("height: 100%; overflow: hidden;", "");
        }
        if (document.documentElement && document.documentElement.style) {
            document.documentElement.style.cssText = document.documentElement.style.cssText.replaceAll("height: 100vh; overflow: hidden;", "");
        }
        if (document.querySelector(".regwall-overlay")) {
            document.querySelector(".regwall-overlay").remove();
        }
    }], "ad-slot-large", "ad-slot-container", "splashy-ad-container", "left-top-ad", ["businessinsider.com", "in-post-sticky only-desktop"], ["jutarnji.hr", "ad--align", false, 1], "box_ad", ["hurriyet", "advMasthead"], "adgrid-ad-container", "adgrid-ad-target", "google-right-ad", "google-bottom-ads", "bottom-ads-container", "mobile-ad", "AdMedium", "pb-ad", "header-ads", "ExternalAdMedium", "sticky-ads", "adplaceholder", "dfp-ad-lazy", "block-fusion-ads", "ad-leaderboard", "bottom-sticky__ad-container", "arc-ad", "ad__slot", "dfp-ad-unit", ["1001games.com", "gc-leaderboard"], "didna-adhesion-bottom", "adRenderer", "adRendererInfinite", "ad-container-wrapper", "pre-article-ad", "revcontent-widget-wrapper", "ad-container-wrapper", "sticky-ad-container", "adCreator", "ad__section-border", "header_ads-container", "sb-fad-unit", "square_fad", "footer-article-fad", "component-ar-horizontal-bar-ad", "inline-ad", "inline-ad--desktop-critical", "component-article-section-inline-ad", "bottomad", "amp-ad-container", ["skincarie.com", "td-adspot-title", false, 1], ["skincarie.com", "ai-rotate", false, 1], "jeg_ad", "jeg_ad_article", "AdContainer", "ytd-ad-slot-renderer", "adsense", "adx", "adthrive", "advertisement", "ad-leaderboard-flex", "taboola-container", "js-ad-desktop", "ad-desktop", "ad-mobile", "ad__wrapper", "js-ad__leaderboard", "ad__leaderboard"];

    var removeids = ["3pCheckIframeId", "div-gpt-ad-codebeautify_org-box-4-0", "div-gpt-ad-codebeautify_org-box-2-0", "div-gpt-ad-codebeautify_org-medrectangle-2-0", "p-Ads", "incontent_player", "carbonads", "AdThrive_Recipe_1_desktop", "taboola-mobile-below-article-thumbnails", "top_ad", "aswift_4_host", "aswift_3_host", "aswift_2_host", "aswift_1_host", "aswift_4", "aswift_3", "aswift_2", "aswift_1", ["ieee.org", "overlay_DFP"], "div-gpt-ad-medium_rectangle_short", ["washingtonpost.com", "leaderboard-wrapper"], "google-top-ads", ["loansocieties.com", "networkRelated-modal-wrapper"], "bottom_sticky_ad", "adrightbottom", "adrighttop", "ad1", ["smithsonianmag.com", "smithsonianmag_adhesion"], ["bbc.com", "sticky-mpu"], ["bbc.com", "sticky-leaderboard"], "ad-standard-wrap", "ob_iframe", "ob_holder", ["yourbump.com", "sm-avantis-container"], ["newsnationnow.com", "widget1"], "AD_Z", "dianomi-module", "ad-feedback__modal-overlay", "skm-ad-frame2", "Lead-0-Ad-Proxy", "Col2-2-Ad-Proxy", ["news.yahoo.com", "viewer-MAST"], ["news.yahoo.com", "viewer-LREC2"], ["yahoo.com", "sda-MAST"], ["yahoo.com", "sda-LDRB2"], ["yahoo.com", "sda-LDRB"],  ["yahoo.com", "sticky-sda-contaisner"], ["yahoo.com", "sda-MON"], "player-ads", ["convertingcolors.com", "_flexbar_"], "push-notifications-primer", "All_Leaderboards", "dp-ads-center-promo_feature_div", "bfad-slot", "sailthru-overlay-container", "ad-backstage-wrap", "ad-article-rail-default-wrapper", "gpt-leaderboard-ad", ["nytimes.com", "top-wrapper"], "div-gpt-ad-top_leaderboard", "div-gpt-ad-interstitial", "taboola-skip", "regiwall-overlay", "top-right-ad-slot", "top-left-ad-slot", "mobile-ad-wrap", "ad-container", "taboola", ["cnx-software.com", "fixeddbar"], ["yahoo.com", "sb_rel_defaultINARTICLE"], ["orbispatches.com", "vi-smartbanner"], ["nytimes.com", "gateway-content"], "baeldung_adhesion", "mvp-post-bot-ad", ["hackaday.com", "leaderboard"], ["nytimes.com", "bottom-wrapper"], "dfp_leaderboard", ["stylefood.ca", "block"], "ad-wrap-bannerTop", "primis-container", "premAd", ["fortune.com", "Leaderboard0"], ["fortune.com", "RightRailFlex0", false, 1], ["fortune.com", "RightRailFlex1", false, 1], "free-start-ads-block", ["washingtonpost.com", "slug_leaderboard", false, 3], "ads_2", "ads_a", "leftrail_dynamic_ad_wrapper", ["gizmodo.com", "commerce-inset-wrapper"], "google-right-ads", "google-bottom-ads", "sticky-ad", "adBot", "top-ad-wrapper", "right1ad", "bottom-sticky-ad_iframe", "bottom-sticky-ad", "bottom-sticky__ad-container", ["*", "arlinablock", false, 0, function() {
        document.body.style.cssText = document.body.style.cssText.replace("overflow: hidden;", "");
    }], "ad-left-aside", "addContainer", ["w3schools.com", "adngin-sidebar_top-0", false, 2], "adngin-mid_content-0", "adngin-bottom_left-0", "adngin-bottom_right-0", "banner_ad", "skyscraper_ad", "mu_2_ad", "left_skyscraper_ad", "ad-leaderboard", "ad-leaderboard-content", ["*", "myblock", false, 0, function() {
        if (document.body) {
            if (document.body.style && document.body.style.cssText && document.body.style.cssText.includes("overflow: hidden;")) {
                document.body.style.cssText = document.body.style.cssText.replaceAll("overflow: hidden;", "");
            }
            if (document.body.classList) {
                document.body.classList.remove("bgclass");
            }
        }
    }], "taboola-right-rail-thumbnails", "vi-smartbanner", "content-advert", "advertisement", "hindsight-ads-iframe", "top-ad", "box-advert", "Arpian-ads", "ad-panel-region"];

    /*
        format of removeids and removeclasses:
        one string: "class/id" to be removed
        array:
            first element of arr: "nytimes.com": only removed if page's hostname matches it; "!reddit.com": only removed if page's hostname DOESN'T match it; "*" to match all hostnames
            second element of arr: "class/id" to be removed
            third element of arr: if falsy, then element is removed; if truthy, element.style.display attribute is set to "none". optional (will be falsy if not set, so "default" behavior).
            fourth element of arr: if undefined or 0, nothing changes. if 1, element.parentNode will be removed. if 2, element.parentNode.parentNode will be removed. if 3, element.parentNode.parentNode.parentNode will be removed. etc... optional.
            fifth element of arr: callback function called right before the element is removed. optional.
    */

    var classfragments = [["ads__index__adWrapper"], ["Advertisement"], ["PageGameAdvertisment"], ["ArticleInjector_clsAvoider"], ["SlideAdPlaceholder__"], ["ad-slot__container"], ["styles-makeit-ad"], ["adWrapper"], ["AdsWrapper"], ["InterstitialWrapper-"], ["-Advert"], ["block-simple-blockad-"], ["VideoAdvert", true], ["adComponent_", true], ["Ad__Container", true], ["BannerAd", true], ["NativeAd", true], ["ad_container", true], ["adUnitWrapper", true], ["ad-wrapper", true]]; // Fragments of classes, such as "Advertisement-jAf_8q e4Rk1". Putting true as the second element of the array sets display to none instead of hiding it.

    var iframesrcfragments = ["googlead", "safeframe.googlesyndication", "adservice", "amazon-adsystem.com", "s.yimg.com/rq", "ads.pubmatic.com/AdServer", "cdn.connectad.io/connectmyusers.php", "acdn.adnxs.com/dmp/async_usersync", "eb2.3lift.com/sync", "crb.kargo.com/api/v1", ".taboola.com/sync", "gum.criteo.com/syncframe?origin=", "pandg.tapad.com/tag", ".rubiconproject.com/usync.html", "contextual.media.net/checksync.php", ".rubiconproject.com/utils/xapi/multi-sync.html", "cdn.krxd.net/partnerjs/xdi/proxy", "imprlatbmp.taboola.com/st?", "cdn-gl.imrworldwide.com/novms/html/ls.html", "pixel.mathtag.com/sync/iframe", "insight.adsrvr.org/track", "jsapicdn.com/prebidlink", "rtb.mfadsrvr.com/sync", "public.servenobid.com/sync.html", "//z.moatads.com/", "csync.loopme.me/", "prebid.a-mo.net/isyn", "//p.medocdn.com/prebidlink/", ".doubleclick.net/activityi;src=", "//sdk.minutemedia-prebid.com/cs-config/cs.html", "//ap.lijit.com/beacon?informer=", "//ssc-cms.33across.com/ps/", "//js-sec.indexww.com/um/ixmatch.html", "//cdn.undertone.com/js/usersync.html", "//onetag-sys.com/usync", "//sdk.streamrail.com/cs-config/cs.html", "//i.liadm.com/", "//hbx.media.net/checksync.php", "//c.aaxads.com/aacxs.php", "//secure-us.imrworldwide.com/storageframe.html", "//sync.quantumdex.io/usersync/", "//cdn.aralego.net/ucfad/cookie/sync.html", "//csync.smilewanted.com", "//ib.adnxs.com/getuid", "//sync.inmobi.com/", "//sync.1rx.io/usersync", "//ap.lijit.com/pixel", "//ssum-sec.casalemedia.com/usermatchredir", "//cs.emxdgt.com/um?redirect=", ".doubleclick.net/pixel?", "//ap.lijit.com/beacon", "//cdn.cxense.com/sp", "//usersync.getpublica.com/usersync", "//ssum.casalemedia.com/usermatch", "//action.publicgood.com/embed.html?", "//ad-cdn.technoratimedia.com/html/usersync.html?", "//beta.kaprila.com/a/templates"];

    var iframeRegexs = [/www\.dianomi\.com\/[a-zA-Z]{1,10}_[a-zA-Z]{1,100}\.epl\?id=\d{1,5}/, /\/\/stags\.bluekai\.com\/site\/\d{1,8}/, /\/\/pixel\.advertising\.com\/[a-zA-Z]{1,5}\/\d{1,7}\/sync/, /\/\/pixel-sync\.sitescout\.com\/[a-zA-Z]{1,5}\/pixelSync/, /\/\/condenast\.demdex\.net\/dest\d{1,2}\.html/, /\/\/[a-zA-Z]{1,9}\.[a-zA-Z]{1,3}\.doubleclick\.net\/[a-zA-Z]{1,6}\/pixel/, /\/\/[a-zA-Z]{1,5}\.demdex\.net\/[a-zA-Z]{1,5}/, /\/\/us-u\.openx\.net\/[a-zA-Z]\/\d.\d\/[a-zA-Z]{0,9}/, /\/\/u\.openx\.net\/[a-zA-Z]\/\d.\d\/[a-zA-Z]{0,9}/, /\/\/[a-zA-Z]{3,20}\.demdex\.net\/dest\d.html/, /\/\/acceptable\.a-ads\.com\/\d/, /\/\/ad\.a-ads\.com\/\d\d/];

    var trackingimagesrcfragments = ["ids.ad.gt/api", "ad-delivery.net/px.gif", "ib.adnxs.com/getuid", "pixel.advertising.com/ups", "trc.taboola.com/sg/audigent/1", "t.co/i/adsct?bci=", "ib.adnxs.com/seg", "//trace.mediago.io/api/log/track", "//trace.mediago.io/api/bidder/track/pixel", "//c.aaxads.com/pxusr.gif", "//www.aaxdetect.com/pxext.gif", "//ssum-sec.casalemedia.com/usermatchredir", "//load77.exelator.com/pixel.gif", "//sync.smartadserver.com/getuid?", "//token.rubiconproject.com/token?", "//sync.mathtag.com/sync/img?", "//ad.360yield.com/ux?", "//match.prod.bidr.io/cookie-sync/", "//sync.1rx.io/usersync/", ".agkn.com/pixel/", ".publishers.tremorhub.com/pubsync?", "https://ssp.behave.com/push_sync", "adsrvr.org/track/pxl", "//ads.stickyadstv.com/user-matching?", "//www.facebook.com/tr?", "//facebook.com/tr?", "//sync.search.spotxchange.com/partner"];

    var imageRegexs = [/\/\/trx-hub\.com\/[a-zA-Z]\/[a-zA-Z]\/[a-zA-Z]\.png/, /\/\/t\.co\/[a-zA-Z]\/adsct\?/, /\/\/analytics\.twitter\.com\/[a-zA-Z]\/adsct\?/, /\/\/zdbb\.net\/[a-zA-Z]\//, /\/\/image\d\.pubmatic\.com\/AdServer\/[a-zA-Z]CookieSet[a-zA-Z]{1,9}/, /\/\/match\.adsrvr\.org\/track\/[a-zA-Z]{1,9}\/generic\?/, /\/\/[a-zA-Z]{1,5}\.demdex\.net\/[a-zA-Z]{1,5}/, /\/\/pixel\.wp\.com\/[a-zA-Z].gif/, /\/\/image\d\.pubmatic\.com\/AdServer\/ImgSync\?/, /\/\/[a-zA-Z0-9]{1,5}.[a-zA-Z]{1,3}\.fwmrm\.net\/ad\/[a-zA-Z]\?/, /\/\/pix\.pub\/[a-zA-Z]\.png/, /\/\/ad\.doubleclick\.net\/[a-zA-Z]{1,5}\/activity\//, /\/\/tag\.researchnow\.com\/[a-zA-Z]{1,3}\/beacon/, /\/\/analytics\.twitter\.com\/[0-9]\?\/\?[a-z]\/adsct/, /\/\/t\.co\/[0-9]\?\/\?[a-z]\/adsct/];

    var scrollingClasses = ["stop-scrolling", "tp-modal-open", "overflow_hidden", "adblock-on", "swal2-shown", "active-paywall"]; // Classes on the document body that prevent scrolling.

    var iframeidfragments = ["openwrap-ad", "ob-user-test", "AVLoaderaniview_slot_", "AVLoaderaniplayer_", "google_ads_", "AVLoaderindependent_ad", "trc-pixel-iframe"];
    
    var dividfragments = ["google_ads_iframe", "superbannerWrapper", "banner-ad", "topad", "adRootContainer", "advertising", "div-gpt-ad", "GFG_AD_", "dfp-ad-", "adboxvertical", "ads-container-", "_papayads_", "ads_header_"];

    function packArray(arr) {
        return JSON.stringify(arr).replace(/","/g, "|");
    }
    function unpackArray(arr) {
        return JSON.parse(arr.replace(/\|/g, "\",\""));
    }
    if (debug.debugEnabled) {
        Element.prototype._remove = Element.prototype.remove;
        Element.prototype.remove = function() {
            console.trace("Adblock about to remove element:", this);
            this._remove();
        }
    }
    var callOverrides = function() {
        if (document.body) {
            document.body.remove = function() {/*set by adblock*/}
            if (typeof document.body.oncontextmenu === "function" && document.body.oncontextmenu.toString() === 'function(){return!1}') {
                document.body.oncontextmenu = function() {/*set by adblock*/};
            }
            if (typeof document.body.oncopy === "function" && document.body.oncopy.toString() === 'function(){return!1}') {
                document.body.oncopy = null;
            }
            if (typeof document.body.onselectstart === "function" && document.body.onselectstart.toString() === 'function(){return!1}') {
                document.body.onselectstart = null;
            }
        }
        if (typeof document.oncontextmenu === "function" && document.oncontextmenu.toString() === 'function(){return false}') {
            document.oncontextmenu = function() {/*set by adblock*/};
        }
        
        delete window.devtoolsDetector;
        window.__defineGetter__("devtoolsDetector", function() {
            console.trace("Devtools detector access trace");
            throw new Error("Attempted to access devtools detector!");
        });
    }
    
    var isBait = function(element) {
        if (element.id === "adblocker_bait") {
            return true;
        }
        if (element.id === "detect" && element.classList && Array.from(element.classList).join(" ") === "ads ad adsbox doubleclick ad-placement carbon-ads ad-box") {
            return true;
        }
        return false;
    }
    
    var removePaywalls = function() {
        if (window.location.host.includes("nationalgeographic.com") &&
            document.body &&
            (document.body.style.cssText.includes("overflow-y: hidden; position: fixed;") || document.body.style.cssText.includes("overflow: hidden; position: fixed;"))) {
            document.body.style.cssText = document.body.style.cssText.replace("overflow-y: hidden; position: fixed;", "");
            document.body.style.cssText = document.body.style.cssText.replace("overflow: hidden; position: fixed;", "");
            if (document.querySelector(".Article__Content__Overlay--gated")) {
                document.querySelector(".Article__Content__Overlay--gated").remove();
            }
        }
        
        if (window.location.host.includes("coolmathgames.com")) {
            if (document.getElementById("continue-link") && document.getElementById("continue-link").innerText) {
                window.cmg_remove_padg();
                start_full_screen_without_ad = false;
            }
            if (document.querySelector(".big-screen-popover-span")) {
                document.querySelector(".big-screen-popover-span").innerText = "Play Fullscreen";
            }
        }
        
        if (window.location.host.includes("pdfrecover.herokuapp.com")) {
            window.gadb = false;
        }
        
        if (document.body && document.body.classList) {
            for (var i in scrollingClasses) {
                if (typeof scrollingClasses[i] === "string") {
                    document.body.classList.remove(scrollingClasses[i]);
                }
            }
            
            for (var i in document.body.classList) {
                if (document.body.classList[i].toString().includes("prevent-scroll")) {
                    document.body.classList.remove(document.body.classList[i].toString());
                }
            }
        }
        
        if (document.documentElement && document.documentElement.classList) {
            document.documentElement.classList.remove("dialog-is-shown");
            for (var i in document.documentElement.classList) {
                if (typeof document.documentElement.classList[i] === "string" && document.documentElement.classList[i].includes("prevent-scroll")) {
                    document.documentElement.classList.remove(document.documentElement.classList[i]);
                }
            }
        }
        
        var allelems = document.getElementsByTagName("*");
        for (var i in allelems) {
            if (!(allelems[i] instanceof HTMLElement)) {
                continue;
            }
            if (Array.from(allelems[i].classList).length > 0 && /ads-\d{1,5}x\d{1,5}/.exec(Array.from(allelems[i].classList).join(" "))) {
                allelems[i].remove(); // (not paywall blocker code)
            }
            if (allelems[i].ariaLabel && (allelems[i].ariaLabel.toLowerCase().includes("sponsored") || allelems[i].ariaLabel.toLowerCase().includes("advert"))) {
                allelems[i].style.display = "none"; // (not paywall blocker code)
            }
            for (var k in allelems[i].classList) {
                if (typeof allelems[i].classList[k] === "string" && allelems[i].classList[k].includes("body__pinnedScrollPaywall")) {
                    allelems[i].classList.remove(allelems[i].classList[k]);
                }
            }
        }
        if (window.location.host.includes("latimes.com") && document.body && document.body.style) {
            for (var i in document.getElementsByTagName("modality-custom-element")) {
                if (document.getElementsByTagName("modality-custom-element")[i] instanceof HTMLElement) {
                    document.getElementsByTagName("modality-custom-element")[i].remove();
                }
            }
            document.body.style.cssText = document.body.style.cssText.replace("overflow: hidden;", "");
        }
        if (window.location.host.includes("nytimes.com")) {
            if (document.getElementById("app") && document.getElementById("app").children[0] && document.getElementById("app").children[0].children[0] instanceof HTMLElement) {
                document.getElementById("app").children[0].children[0].style.position = "static";
                if (document.getElementById("app").children[0].children[0].children[2] instanceof HTMLElement) {
                    document.getElementById("app").children[0].children[0].children[2].remove();
                }
            }
            var sitecontent = document.getElementById("site-content");
            if (sitecontent && sitecontent.style.cssText.includes("position: fixed;")) {
                sitecontent.style.cssText = sitecontent.style.cssText.replace("position: fixed;", "")
            }
        }
    }
    
    var msnremoveads = function() {
        var elements = document.getElementsByTagName("DESKTOP-FEED-VIEWS");

        for (var i in elements) {
            let shadowroot = elements[i].shadowRoot;
            if (!shadowroot) {
                continue;
            }
            shadowroot = shadowroot.children[0];
            let layouts = shadowroot.getElementsByTagName("MSFT-FEED-LAYOUT");
            let smallshadowroots = [];
            for (var k in layouts) {
                if (layouts[k].shadowRoot) {
                    smallshadowroots.push(layouts[k].shadowRoot);
                }
            }
            for (var l in smallshadowroots) {
                var articles = smallshadowroots[l].querySelectorAll("MSFT-ARTICLE");
                for (var p in articles) {
                    if (articles[p] && articles[p].id && articles[p].id.includes("native_ad_")) {
                        if (articles[p].parent) {
                            articles[p].parent.remove();
                        }
                    }
                }
            }
        }
    }
    var adblockta = async function() {
        try {
            window.isBlocked = false;
            window.google_unique_id = 1;
            if (window.adsbygoogle) {
                window.adsbygoogle.loaded = true;
            }
            if (debug.enabled) {
                debug.currentString = "";
                debug.starttime = Date.now();
            }
            debug.debugTime("callOverrides()");
            callOverrides();
            debug.debugTime("iFrame removal");
            for (var i in document.getElementsByTagName("iframe")) {
                var theframe = document.getElementsByTagName("iframe")[i];
                if (!(theframe instanceof HTMLElement)) {
                    continue;
                }
                if (typeof theframe.title === "string" && theframe.title.toLowerCase() === "ad") {
                    theframe.remove();
                }
                if (theframe.style && (theframe.style.cssText.includes("!important; opacity: 1 !important; max-width: 100% !important; border: 0px !important; position: fixed !important; display: block !important; z-index: 2147483647 !important; inset") || theframe.style.cssText.includes("border: none !important; position: fixed !important; display: block !important; z-index: 2147483647 !important; inset") || theframe.style.cssText.includes("position: fixed !important; display: block !important; z-index: 2147483647 !important; margin: 0px !important; padding: 0px !important; outline: none !important; border: none !important; background-color: transparent !important;"))) {
                    theframe.remove();
                }
                for (var k in iframesrcfragments) {
                    if (theframe.src && theframe.src.includes(iframesrcfragments[k])) {
                        document.getElementsByTagName("iframe")[i].remove();
                    }
                }
                for (var j in iframeRegexs) {
                    if (iframeRegexs[j] instanceof RegExp && iframeRegexs[j].exec(theframe.src)) {
                        theframe.remove();
                    }
                }
                
                if (!(typeof theframe.id === "string")) {
                    continue;
                }
                
                for (var d in iframeidfragments) {
                    if (theframe.id.includes(iframeidfragments[d])) {
                        theframe.remove();
                    }
                }
            }
            /*
            debug.debugTime("removal of elements containing adsbygoogle code");
            var scripts = document.getElementsByTagName("script");
            for (var i in scripts) {
                if (scripts[i].innerText && scripts[i].innerText.trim() === "(adsbygoogle = window.adsbygoogle || []).push({});") {
                    scripts[i].parentNode.remove();
                }
            }*/ //This broke a lot of stuff, unfortunately
            
            debug.debugTime("div removal");
            var divs = document.getElementsByTagName("div");
            for (var i in divs) {
                // General div-related removal
                
                var thediv = divs[i];
                if (!thediv) {
                    continue;
                }
                if (thediv.id) {
                    if (isBait(thediv)) {
                        logger.log("Adblock: Found adblocker bait, but not removing.");
                        continue;
                    }
                    for (var i in dividfragments) {
                        if (thediv.id.includes(dividfragments[i])) {
                            thediv.remove();
                        }
                    }
                    if (window.location.host.includes("linuxquestions.org") && thediv.id.includes("amzn_assoc_ad_div")) {
                        thediv.parentNode.remove();
                    }
                    if (window.location.host.includes("reddit.com") && thediv.outerHTML.startsWith("<div data-before-content=\"advertisement\"")) {
                        thediv.parentElement.remove();
                    }
                    if (/mrt-node-Col\d-\d-Ad/.exec(thediv.id)) {
                        thediv.remove();
                    }
                    if (/gdm-script-\d{1,4}-container/.exec(thediv.id)) {
                        thediv.remove();
                    }
                    if (/story-ad-\d-wrapper/.exec(thediv.id)) {
                        thediv.remove();
                    }
                }
                if (thediv.style && (thediv.style.cssText.includes("position: fixed; inset: 0px; z-index: 2147483647; background: black; opacity: 0.01; height:") || thediv.style.cssText.includes("z-index: 2147483647 !important; position: fixed !important; width: "))) {
                    thediv.style.display = "none";
                }
                if (thediv.classList) {
                    thediv.classList.remove("paywallActive");
                    if (window.location.host.includes("latimes.com")) {
                        if (Array.from(thediv.classList).indexOf("subscriber-content") !== -1) {
                            thediv.classList.remove("subscriber-content");
                        }
                    }
                    for (var k in classfragments) {
                        if (Array.from(thediv.classList).join("").includes(classfragments[k][0])) {
                            if (classfragments[k][1]) {
                                thediv.style.display = "none";
                            } else {
                                thediv.remove();
                            }
                        }
                    }
                }
                if (thediv.dataset) {
                    if (thediv.dataset.adPlaceholder ||
                        (thediv.dataset.beforeContent && thediv.dataset.beforeContent.toLowerCase() === "advertisement") ||
                        (thediv.dataset.content && thediv.dataset.content.toLowerCase() === "advertisement") ||
                        thediv.dataset.adStatus ||
                        thediv.dataset.freestarAd ||
                        thediv.dataset.widgetType === "ads" ||
                        thediv.dataset.qa === "article-body-ad" ||
                        thediv.dataset.qa === "right-rail-ad" ||
                        thediv.dataset.testId === "right-rail-ad" ||
                        thediv.dataset.testid /* Capitalization is intentional */ === "StandardAd" ||
                        thediv.dataset.ad ||
                        (thediv.dataset.testId && thediv.dataset.testId.includes("ad-container")) ||
                        (thediv.dataset.componentRoot && thediv.dataset.componentRoot.toLowerCase() === "leaderboardad") ||
                        thediv.dataset.title === "Advertisement") {
                        thediv.remove();
                    }
                    for (var z in thediv.dataset) {
                        if (z.toLowerCase().includes("adunit")) {
                            thediv.remove();
                        }
                    }
                }
                if (thediv.ariaLabel && (thediv.ariaLabel.toLowerCase().includes("sponsored") || thediv.ariaLabel.toLowerCase().includes("advert"))) {
                    thediv.remove();
                }
            }
            
            // General class and id-specific removal code past here
            debug.debugTime("class removal");
            
            if (window.location.host.includes("nbcnews.com")) {
                var adContainers = document.getElementsByClassName("ad-container");
                for (var i in adContainers) {
                    if (adContainers[i] instanceof HTMLElement) {
                       adContainers[i].style.display = "none";
                    }
                }
                var taboolas = document.getElementsByClassName("taboola");
                for (var i in taboolas) {
                    if (taboolas[i] instanceof HTMLElement) {
                       taboolas[i].style.display = "none";
                    }
                }
            } else {
                for (var q in removeclasses) {
                    var clas = removeclasses[q];
                    if (Array.isArray(clas)) {
                        var traversenum = clas[3] || 0;
                        var clas2 = clas[0];
                        var clas3 = clas[2];
                        var callback = clas[4] || (function() {});
                        clas = clas[1];
                        if (clas2 === "*" || window.location.host.includes(clas2) || (clas2.startsWith("!") && !window.location.host.startsWith(clas2.slice(1)))) {
                            var allElems = document.getElementsByClassName(clas);
                            for (var i in allElems) {
                                var elem = allElems[i];
                                if (elem && elem instanceof HTMLElement) {
                                    if (elem.id && isBait(elem)) {
                                        logger.log("Adblock: Found adblocker bait, but not removing.");
                                        continue;
                                    }
                                    for (var p = 0; p < traversenum; p ++) {
                                        if (elem.parentNode) {
                                            elem = elem.parentNode;
                                        }
                                    }
                                    if (clas3) {
                                        callback();
                                        elem.style.display = "none";
                                    } else {// ads ad adsbox doubleclick ad-placement carbon-ads ad-box: Class, detect: Id
                                        if (typeof elem.remove === "function") {
                                            callback();
                                            elem.remove();
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        var allElems = document.getElementsByClassName(clas);
                        for (var i in allElems) {
                            if (allElems && allElems[i] && typeof allElems[i].remove === "function") {
                                var elementToRemove = allElems[i];
                                if (elementToRemove.id && isBait(elementToRemove)) {
                                    logger.log("Adblock: Found adblocker bait, but not removing.");
                                    continue;
                                }
                                elementToRemove.remove();
                            }
                        }
                    }
                }
            }
            debug.debugTime("id removal");
            for (var j in removeids) {
                var clas = removeids[j];
                if (Array.isArray(clas)) {
                    var traversenum = clas[3] || 0;
                    var clas2 = clas[0];
                    var clas3 = clas[2];
                    var callback = clas[4] || (function() {});
                    clas = clas[1];
                    if (clas2 === "*" || window.location.host.includes(clas2) || (clas2.startsWith("!") && !window.location.host.startsWith(clas2.slice(1)))) {
                        var elem = document.getElementById(clas);
                        if (elem) {
                            for (var p = 0; p < traversenum; p ++) {
                                if (elem.parentNode) {
                                    elem = elem.parentNode;
                                }
                            }
                            if (typeof elem.remove === "function") {
                                callback();
                                if (clas3) {
                                    elem.style.display = "none";
                                } else {
                                    elem.remove();
                                }
                            }
                        }
                    }
                } else {
                    var elem = document.getElementById(removeids[j]);
                    if (elem && typeof elem.remove === "function") {
                        elem.remove();
                    }
                }
            }
            // Paywall blocker/anti-anti-adblock code past here
            debug.debugTime("paywall remover");
            if (!window.location.host.includes("youtube.com")) {
                removePaywalls();
                var trickelement = document.createElement("span");
                trickelement.style.height = "1px";
                trickelement.style.width = "1px";
                trickelement.className = "adsbygoogle";
                if (document.documentElement) {
                    document.documentElement.append(trickelement);
                }
            }
            
            /*
            
            // Tracking image remover code past here
            
            // Remember to be extremely selective when adding code here
            debug.debugTime("tracking image removal");
            
            for (var i in document.getElementsByTagName("img")) {
                var theimg = document.getElementsByTagName("img")[i];
                if (!(theimg instanceof HTMLElement)) {
                    continue;
                }
                if (theimg.height > 8 || theimg.width > 8) { // Just to check for tracking images up to 8x8
                    continue;
                }
                for (var j in trackingimagesrcfragments) {
                    if (theimg.src.includes(trackingimagesrcfragments[j])) {
                        theimg.remove();
                    }
                }
                for (var z in imageRegexs) {
                    if (typeof imageRegexs[z].exec === "function" && imageRegexs[z].exec(theimg.src)) {
                        theimg.remove();
                    }
                }
            }*/ // Hosts file should block tracking images anyway
            
            // Close button presses past here
            debug.debugTime("press close buttons");
            
            for (var i in document.getElementsByClassName("pgCloseBtn")) {
                if (document.getElementsByClassName("pgCloseBtn") && document.getElementsByClassName("pgCloseBtn")[i] && typeof document.getElementsByClassName("pgCloseBtn")[i].click === "function") {
                    document.getElementsByClassName("pgCloseBtn")[i].click();
                }
            }
            for (var i in document.getElementsByClassName("closeBtnCircular")) {
                if (document.getElementsByClassName("closeBtnCircular") && document.getElementsByClassName("closeBtnCircular")[i] && typeof document.getElementsByClassName("closeBtnCircular")[i].click === "function") {
                    document.getElementsByClassName("closeBtnCircular")[i].click();
                }
            }
            if (document.getElementById("close-btn") && typeof document.getElementById("close-btn").click === "function") {
                document.getElementById("close-btn").click();
            }
            if (document.getElementById("model__close") && typeof document.getElementById("model__close").click === "function") {
                document.getElementById("model__close").click();
            }
            
            // These sites are ones I'll never use but maybe someone else might
            
            debug.debugTime("other");
            if (window.location.host.includes("enjoytaiwan.co.kr") && typeof h237 !== "undefined") {
                h237.nextFunction = function() {}
            }
            if (window.location.host.includes("us.tamrieltradecentre.com") && window.SearchResultViewModel && window.SearchResultViewModel.prototype) {
                window.SearchResultViewModel.prototype.IsAdLoadedOnElement = function() {
                    return true;
                }
            }
            
            // Specific removal of elements based on hostname past here
            
            debug.debugTime("hostname-specific element removal");
            
            if (window.location.host.includes("news.yahoo.com")) {
                for (var i in document.getElementsByClassName("native-ad-item")) {
                    if (document.getElementsByClassName("native-ad-item")[i].parentNode && document.getElementsByClassName("native-ad-item")[i].parentNode) {
                        if (document.getElementsByClassName("native-ad-item")[i].parentNode.tagName === "LI") {
                            document.getElementsByClassName("native-ad-item")[i].parentNode.remove();
                        }
                    }
                }
            }
            if (window.location.host.includes("hackaday.com")) {
                document.getElementById("secondary").style.marginTop = "0px";
            }
            if (window.location.host.includes("msn.com")) {
                msnremoveads();
            }
            if (document.body && document.body.style && document.body.style.backgroundImage && document.body.style.backgroundImage.includes("tpc.googlesyndication.com")) {
                document.body.style.backgroundImage = "";
            }
            if (document.getElementById("disqus_thread") && document.getElementById("disqus_thread").children[0] && document.getElementById("disqus_thread").children[0].src === '' && document.getElementById("disqus_thread").children[0].tagName.toLowerCase() === "iframe") {
                document.getElementById("disqus_thread").children[0].remove();
            }
            if (window.location.host.includes("vice.com")) {
                if (document.querySelector(".main-content").children[0].style.height === "273px") {
                    document.querySelector(".main-content").children[0].remove();
                }
            }
            if (window.location.host.includes("forbes.com")) {
                var elems = document.getElementsByTagName("FBS-AD");
                for (var i in elems) {
                    if (elems[i] instanceof HTMLElement) {
                        elems[i].remove();
                    }
                }
            }
            if (window.location.host.includes("washingtonpost.com") && document.body && document.body.style && document.body.style.cssText.includes("position: fixed")) {
                document.body.style = document.body.style.cssText.replace("position: fixed;", "");
            }
            if (window.location.host.includes("soranews24.com")) {
                window.jQuery = function() {};
                var imgs = document.getElementsByClassName("lazy aligncenter");
                var imgsr = [];
                for (var i in imgs) {
                    if (imgs[i] instanceof HTMLImageElement) {
                        imgsr.push(imgs[i]);
                    }
                }
                for (var i in imgsr) {
                    if (!(imgsr[i] && imgsr[i].parentNode)) {
                        continue;
                    }
                    var noscripttxt = imgsr[i].parentNode.getElementsByTagName("noscript")[0].innerText;
                    imgsr[i].parentNode.innerHTML = noscripttxt;
                }
            }
            if (window.location.host.includes("ckk.ai") || window.location.host.includes("go.techgeek.digital")) {
                if (window.app_vars) {
                    app_vars['force_disable_adblock'] = "0";
                }
                var iframes = document.getElementsByTagName("iframe");
                for (var m in iframes) {
                    if (iframes[m] && iframes[m].style && iframes[m].style.cssText.includes("display: block; border: none; position: fixed; z-index: 2147483647; max-width: 90%; margin: auto; width: 410px; height: 150px; inset: ")) {
                        logger.log("Adblock: Blocked an in-page popup.");
                        iframes[m].remove();
                    }
                }
            }
        } catch(e) {logger.log("Adblock: Error:", e)}
    };
    if (/*!window.location.host.includes("youtube.com")*/true) {
        var intervaltime = 500;
        if (window.location.host.includes("youtube.com")) {
            intervaltime = 750;
        }
        if (debug.enabled) {
            intervaltime = 5000;
        }
        adblockta();
        window.setInterval(adblockta, intervaltime);
    }

    if (window.location.host.includes("blog.xkcd.com")) {
        var comments = document.getElementsByClassName("comment-body");
        for (var i in comments) {
            if (comments[i] instanceof HTMLElement && comments[i].children[1]) {
                if (/[ a-zA-Z\,\.\'\"-%:\?’]{5,100}[ ]{0,}<a /.exec(comments[i].children[1].children[0].innerHTML)) {
                    comments[i].parentNode.remove();
                }
            }
        }
    }

    if (window.location.host.includes("quora.com") && !window.location.search.includes("share=1")) {
        if (window.location.search.startsWith("?")) {
            window.location.search += "&share=1";
        } else {
            window.location.search = "?share=1";
        }
    }

    if (window.location.host === "theannoyingsite.com" && window.location.pathname === "/") {
        document.write("Might not want to go to this site. :\\")
    }
    console.log("Adblock: Adblocker loaded!");
})();
