const http = require('http');
const https = require('https');
const fs = require('fs');

const options = {
  key: fs.readFileSync('/etc/ssl/private/ssl-cert-snakeoil.key'),
  cert: fs.readFileSync('/etc/ssl/certs/ssl-cert-snakeoil.pem')
};
var server = http.createServer(function (req, res) {
    res.write("");
    res.end();
});
var server2 = https.createServer(options, function (req, res) {
    res.write("");
    res.end();
});
server.listen(80);
server2.listen(443);
